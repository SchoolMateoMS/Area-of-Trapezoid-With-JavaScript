// Calculator for area of trapezoid
// detects a click on the button, and activates the function "Calculate"
document.getElementById("btn").addEventListener("click", Calculate);

// input
// Calculate is a function with all our variables, and it combines them to get the answer
function Calculate() {
    // takes the LengthOfA varible, and gives it the value of the id lengthA
    let LengthOfA = +document.getElementById("lengthA").value;
    // takes the LengthOfB varible, and gives it the value of the id lengthB
    let LengthOfB = +document.getElementById("lengthB").value;
    // takes the height varible, and gives it the value of the id height
    let height = +document.getElementById("height").value;
    // does all the math, and combines all of the variables.
    let Answer = ((LengthOfA + LengthOfB) / 2) * height;
    // displays answer.
    document.getElementById("paragraphAnswer").innerHTML = Answer;
}